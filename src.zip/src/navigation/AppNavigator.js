import React, { useState, useEffect } from 'react';
import { View, ActivityIndicator } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';

// ✅ v22 modular imports
import { getAuth, onAuthStateChanged } from '@react-native-firebase/auth';

import LoginScreen from '../screens/LoginScreen';
import SignupScreen from '../screens/SignupScreen';
import Splash from '../screens/Splash';
import TabNavigator from '../navigation/TabNavigator';
import ChatScreen from '../screens/ChatScreen';

const Stack = createStackNavigator();

const AppNavigator = () => {
  const [initializing, setInitializing] = useState(true);
  const [user, setUser] = useState(null);

  useEffect(() => {
    let auth;
    try {
      auth = getAuth();
    } catch (e) {
      console.log('Auth init error:', e);
      setInitializing(false); // ✅ prevent infinite loader if firebase fails
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, firebaseUser => {
      console.log('Auth state changed:', firebaseUser?.email ?? 'no user'); // ✅ helps debug
      setUser(firebaseUser ?? null);
      setInitializing(false);
    });

    // ✅ Safety fallback — if onAuthStateChanged never fires (rare), stop loading after 5s
    const timeout = setTimeout(() => {
      setInitializing(false);
    }, 5000);

    return () => {
      unsubscribe();
      clearTimeout(timeout);
    };
  }, []);

  if (initializing) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color="#002DE3" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {user ? (
          <>
            <Stack.Screen name="Main" component={TabNavigator} />
            <Stack.Screen
              name="Chat"
              component={ChatScreen}
              options={{ headerShown: true, title: 'Messages' }}
            />
          </>
        ) : (
          <>
            <Stack.Screen name="Splash" component={Splash} />
            <Stack.Screen name="Login" component={LoginScreen} />
            <Stack.Screen name="Signup" component={SignupScreen} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default AppNavigator;